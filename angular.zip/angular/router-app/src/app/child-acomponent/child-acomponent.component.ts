import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child-acomponent',
  templateUrl: './child-acomponent.component.html',
  styleUrls: ['./child-acomponent.component.scss']
})
export class ChildAComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
