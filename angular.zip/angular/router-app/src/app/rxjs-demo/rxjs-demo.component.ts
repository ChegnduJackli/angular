import { Component, OnInit } from '@angular/core';
import { Observable,of } from 'rxjs';
@Component({
  selector: 'app-rxjs-demo',
  templateUrl: './rxjs-demo.component.html',
  styleUrls: ['./rxjs-demo.component.scss']
})
export class RxjsDemoComponent implements OnInit {

  constructor() {  }

  ngOnInit(): void {
    this.test1();
    }
  
    test1(){
      const myObservable = of(1, 2, 3);

      // Create observer object
      const myObserver = {
        next: x => console.log('Observer got a next value: ' + x),
        error: err => console.error('Observer got an error: ' + err),
        complete: () => console.log('Observer got a complete notification'),
      };
      myObservable.subscribe(myObserver);
    }

  }

