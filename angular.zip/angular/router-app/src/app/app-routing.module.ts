import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FirstComponent } from '../app/first/first.component';
import { SecondComponent } from '../app/second/second.component';
import { ChildAComponentComponent } from '../app/child-acomponent/child-acomponent.component';
import { ChildBComponentComponent } from '../app/child-bcomponent/child-bcomponent.component';
import {PageNotFoundComponent} from '../app/page-not-found/page-not-found.component';
 //import {HeroListComponent} from '../app/heroes/hero-list/hero-list.component';
 import {CrisisListComponent} from '../app/crisis-list/crisis-list.component';
import {RxjsDemoComponent} from '../app/rxjs-demo/rxjs-demo.component';

const routes: Routes = [
  //{
    //第一个属性 path 定义了该路由的 URL 路径。第二个属性 component 定义了要让 Angular 用作相应路径的组件。
  //   path: 'first-component', component: FirstComponent, children: [
  //     {
  //       path: 'child-a',
  //       component: ChildAComponentComponent,
  //     },
  //     {
  //       path: 'child-b',
  //       component: ChildBComponentComponent,
  //     },
  //   ]
  // },
  // { path: 'second-component', component: SecondComponent },
  // { path: '', redirectTo: '/first-component', pathMatch: 'full' }, // redirect to `first-component`
  // { path: 'heroes', component: HeroListComponent },
  // { path: '**', component: PageNotFoundComponent },
  
  { path: 'crisis-center', component: CrisisListComponent },
  { path: 'rxjs-demo', component: RxjsDemoComponent },
  // { path: 'heroes', component: HeroListComponent },
   { path: '',   redirectTo: '/heroes', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes,{enableTracing:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
