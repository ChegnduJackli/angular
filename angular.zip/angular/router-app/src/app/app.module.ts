import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }    from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { ChildAComponentComponent } from './child-acomponent/child-acomponent.component';
import { ChildBComponentComponent } from './child-bcomponent/child-bcomponent.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HeroesModule }            from './heroes/heroes.module';
//import { HeroListComponent }     from './heroes/hero-list/hero-list.component';
import { CrisisListComponent } from './crisis-list/crisis-list.component';
import { RxjsDemoComponent } from './rxjs-demo/rxjs-demo.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    ChildAComponentComponent,
    ChildBComponentComponent,
    PageNotFoundComponent,
    
   // HeroListComponent,
    
    CrisisListComponent,
    
   RxjsDemoComponent
  ],
  imports: [
    BrowserModule,
   
    BrowserAnimationsModule,
    FormsModule,
   HeroesModule,
   AppRoutingModule,//请注意该模块的 imports 数组，AppRoutingModule 是最后一个，并且位于 HeroesModule 之后。
   //路由配置的顺序很重要，因为路由器会接受第一个匹配上导航所要求的路径的那个路由。
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
