import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child-bcomponent',
  templateUrl: './child-bcomponent.component.html',
  styleUrls: ['./child-bcomponent.component.scss']
})
export class ChildBComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
