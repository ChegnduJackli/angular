import { Component, OnInit,Input, Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-input-output',
  templateUrl: './input-output.component.html',
  styleUrls: ['./input-output.component.scss']
})
export class InputOutputComponent implements OnInit {
  @Input() item: string; //外层的输入参数
  @Output() deleteRequest = new EventEmitter<string>(); //从子层传递到层
  constructor() { }

  ngOnInit(): void {
  }

  deleteItem(value: string) {
    this.deleteRequest.emit(value);
  }

  delete() {
    console.warn('Child says: emiting item deleteRequest with', this.item);
    this.deleteRequest.emit(this.item);

  }
}
