import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HighlighDirective } from './highligh.directive';

import { FlyingHeroesImpurePipe, FlyingHeroesPipe } from './flying-heroes.pipe';
import { PowerBoostCalculatorComponent } from './power-boost-calculator.component';
import { PowerBoosterComponent } from './power-booster.component';
import { ExponentialStrengthPipe } from './exponential-strength.pipe';
import { FlyingHeroesComponent } from './flying-heroes/flying-heroes.component';
import { HeroAsyncMessageComponent } from './hero-async-message.component';
import { FetchJsonPipe } from './fetch-json.pipe';
import { ItemDetailComponent } from './item-detail/item-detail.component';
import { ItemOutputComponent } from './item-output/item-output.component';
import { InputOutputComponent } from './input-output/input-output.component';
import { PeekABooComponent } from './peek-a-boo/peek-a-boo.component';
import { OnChangeComponent } from './on-change/on-change.component';
import { SpyDirective } from './spy.directive';
import { SpyComponent } from './spy/spy.component';
import { PeekABooParentComponent } from './peek-a-boo-parent/peek-a-boo-parent.component';
import { HeroChildComponent } from './hero-child/hero-child.component';
import { HeroParentComponent } from './hero-parent/hero-parent.component';
import { NameChildComponent } from './name-child/name-child.component';
import { NameParentComponent } from './name-parent/name-parent.component';
import { OnChangeParentComponent } from './on-change-parent/on-change-parent.component';
import { CountdownTimerComponent } from './countdown-timer/countdown-timer.component';
import { CountdownTimerParentComponent } from './countdown-timer-parent/countdown-timer-parent.component';
import { AdDirective } from './ad.directive';
import { AdBannerComponent } from './ad-banner/ad-banner.component';
import { HeroJobAdComponent }   from './ad-banner/hero-job-ad.component';
import { HeroProfileComponent } from './ad-banner/hero-profile.component';
import { AdService }            from './ad-banner/ad.service';
import { ReactiveFavoriteColorComponent } from './reactive-favorite-color/reactive-favorite-color.component';
import { ForbiddenValidatorDirective } from '../app/share/forbidden-name.directive';
import { IdentityRevealedValidatorDirective } from '../app/share/identity-revealed.directive';
import { DynamicFormQuestionComponent } from './dynamic-form-question/dynamic-form-question.component';
import { DynamicFormComponent }         from './dynamic-form-question/dynamic-form.component';

@NgModule({
  declarations: [
    AppComponent,
    HighlighDirective,
    PowerBoosterComponent,
    PowerBoostCalculatorComponent,
    ExponentialStrengthPipe,
    FlyingHeroesComponent,
    FlyingHeroesPipe,
    FlyingHeroesImpurePipe,
    HeroAsyncMessageComponent,
    FetchJsonPipe,
    ItemDetailComponent,
    ItemOutputComponent,
    InputOutputComponent,
    PeekABooComponent,
    OnChangeComponent,
    SpyDirective,
    SpyComponent,
    PeekABooParentComponent,
    HeroChildComponent,
    HeroParentComponent,
    NameChildComponent,
    NameParentComponent,
    OnChangeParentComponent,
    CountdownTimerComponent,
    CountdownTimerParentComponent,
    AdDirective,
    AdBannerComponent,
    HeroJobAdComponent,
    HeroProfileComponent,
    ReactiveFavoriteColorComponent,
    ForbiddenValidatorDirective,
    IdentityRevealedValidatorDirective,
    DynamicFormQuestionComponent,
    DynamicFormComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, //双向绑定
    ReactiveFormsModule,//form control
    HttpClientModule
  ],
  entryComponents: [ HeroJobAdComponent, HeroProfileComponent ],//动态组件
  providers: [AdService], //服务需要放在provider
  bootstrap: [AppComponent]
})
export class AppModule { }
