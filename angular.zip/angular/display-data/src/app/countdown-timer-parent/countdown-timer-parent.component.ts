import { Component, OnInit,ViewChild,AfterViewInit } from '@angular/core';
import {CountdownTimerComponent} from '../countdown-timer/countdown-timer.component';

@Component({
  selector: 'app-countdown-timer-parent',
  templateUrl: './countdown-timer-parent.component.html',
  styleUrls: ['./countdown-timer-parent.component.scss']
})
export class CountdownTimerParentComponent implements OnInit,AfterViewInit  {

  @ViewChild(CountdownTimerComponent)
  private timerComponent: CountdownTimerComponent;

  constructor() { }

  seconds() { return 0; }

  ngAfterViewInit() {
    // Redefine `seconds()` to get from the `CountdownTimerComponent.seconds` ...
    // but wait a tick first to avoid one-time devMode
    // unidirectional-data-flow-violation error
    setTimeout(() => this.seconds = () => this.timerComponent.seconds, 0);
  }

  ngOnInit(): void {
  }

  start() { this.timerComponent.start(); }
  stop() { this.timerComponent.stop(); }

}
