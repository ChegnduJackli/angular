import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { forbiddenNameValidator } from '../share/forbidden-name.directive';
import { identityRevealedValidator } from '../share/identity-revealed.directive';

@Component({
  selector: 'app-reactive-favorite-color',
  templateUrl: './reactive-favorite-color.component.html',
  styleUrls: ['./reactive-favorite-color.component.scss']
})
export class ReactiveFavoriteColorComponent implements OnInit {

  favoriteColorControl = new FormControl('t');
  favoriteColor = 'tt';

  // profileForm = new FormGroup({
  //   firstName: new FormControl(''),
  //   lastName: new FormControl(''),
  //   //嵌套的表单组
  //   address: new FormGroup({
  //     street: new FormControl(''),
  //     city: new FormControl(''),
  //     state: new FormControl(''),
  //     zip: new FormControl('')
  //   })
  // });

  profileForm = this.fb.group({
    firstName: ['', Validators.required],
    lastName: [''],
    address: this.fb.group({
      street: [''],
      city: [''],
      state: [''],
      zip: ['']
    }),
    aliases: this.fb.array([
      this.fb.control('')
    ])
  });

  heroForm = new FormGroup({
    'name': new FormControl('', [
      Validators.required,
      Validators.minLength(4),
      forbiddenNameValidator(/bob/i) // <-- Here's how you pass in the custom validator.
    ]),
    'alterEgo': new FormControl(''),
    //'power': new FormControl(this.hero.power, Validators.required)
  },{validators:identityRevealedValidator});

  get name() { return this.heroForm.get('name'); }

  get power() { return this.heroForm.get('power'); }

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
  }
  updateName() {
    this.favoriteColorControl.setValue('Nancy');
  }

  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.profileForm.value);
  }

  submitHero() {
    console.warn(this.heroForm.value);
  }

  updateProfile() {
    this.profileForm.patchValue({
      firstName: 'Nancy',
      address: {
        street: '123 Drew Street'
      }
    });
  }

  get aliases() {
    return this.profileForm.get('aliases') as FormArray;
  }

  addAlias() {
    this.aliases.push(this.fb.control(''));
  }

}
