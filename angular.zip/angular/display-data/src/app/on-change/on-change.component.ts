import { Component, OnInit,Input, OnChanges,
  SimpleChanges, ViewChild } from '@angular/core';

class Hero {
    constructor(public name: string) {}
  }

@Component({
  selector: 'app-on-change',
  templateUrl: './on-change.component.html',
  styleUrls: ['./on-change.component.scss']
})
export class OnChangeComponent implements OnInit {

  @Input() hero: Hero;
  @Input() power: string;
  @Input() major: number;
  @Input() minor: number;

  constructor() { }

  ngOnInit(): void {
  }

  changeLog: string[] = [];

  ngOnChanges(changes: SimpleChanges) {

    for (let propName in changes) {
      let chng = changes[propName];
      let cur  = JSON.stringify(chng.currentValue);
      let prev = JSON.stringify(chng.previousValue);
      this.changeLog.push(`${propName}: currentValue = ${cur}, previousValue = ${prev}`);
    }
  }

  reset() { this.changeLog = []; }

}
