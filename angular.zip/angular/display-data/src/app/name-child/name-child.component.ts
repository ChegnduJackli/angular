import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-name-child',
  templateUrl: './name-child.component.html',
  styleUrls: ['./name-child.component.scss']
})
export class NameChildComponent implements OnInit {
//通过 setter 截听输入属性值的变化
  private _name = '';
  constructor() { }

  ngOnInit(): void {
  }

  @Input()
  set name(name: string) {
    this._name = (name && name.trim()) || '<no name set>';
  }

  get name(): string { return this._name; }

}
