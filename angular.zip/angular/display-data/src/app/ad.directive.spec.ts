import { AdDirective } from './ad.directive';

describe('AdDirective', () => {
  it('should create an instance', () => {
    const directive = new AdDirective();
    expect(directive).toBeTruthy();
  });
});
