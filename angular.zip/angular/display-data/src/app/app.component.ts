import { AfterViewInit, Component, ElementRef, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Hero } from './hero';

import { AdService }         from '../app/ad-banner/ad.service';
import { AdItem }            from '../app/ad-banner/ad-item';

import { QuestionService } from '../app/dynamic-form-question/question.service';
import { QuestionBase }    from '../app/dynamic-form-question/question-base';
import { Observable }      from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers:  [QuestionService]
})
export class AppComponent {
  title = '英雄指南';
  recommended = "test";
  itemImageUrl2 = "../assets/bg.jpg";
  values = '';
  values2= '';
  item={};
  currentItem ='Television';
  ads: AdItem[];
  questions$: Observable<QuestionBase<any>[]>;
  //heroes:Hero[];// = Hero.heroes;
  constructor(private adService: AdService,service: QuestionService) {
    this.questions$ = service.getQuestions();

  }

  ngOnInit() {
    this.ads = this.adService.getAds();
  }

  heroes = Hero.heroes.map(hero => hero.clone());

  customers = [
    { id: 1, name: 'jack' },
    { id: 2, name: 'rose' },
  ];

  isUnchanged:boolean = true;
  color = 'red';
  birthday = new Date(1988, 3, 15);   
  toggle = true;  // start with true == shortDate

  get format()   { return this.toggle ? 'shortDate' : 'fullDate'; }
  toggleFormat() { this.toggle = !this.toggle; }
  
  deleteHero(hero?: Hero) {
    console.log(`Delete ${hero ? hero.name : 'the hero'}.`);
  };


  // onKey(event: any) { // without type info
  //   this.values += event.target.value + ' | ';
  // };

  onKey(event: KeyboardEvent) { //使用了带类型方法：
    this.values += (event.target as HTMLInputElement ).value + ' | ';
  };
  onKey2(value:string){
    this.values2 += value + ' | ';
  };

  onKey3(value:string){
    this.currentItem =value;
  }

  addHero(newHero: string) {
    if (newHero) {
      this.heroes.push(new Hero(1,newHero,'happy'));
    }
  };

  items = ['item1', 'item2', 'item3', 'item4'];
  addItem(newItem: string) {
    this.items.push(newItem);
  }
  crossOffItem(newItem:string){
    console.log('delete newItem',newItem);

  }

}
